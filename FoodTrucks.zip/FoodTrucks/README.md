#Installation guide

Install dependencies/build program - 
					Install maven in local and run the project using the command "mvn clean install" in FoodTrucks project
					The project bulds and creates FoodTrucks-0.0.1-SNAPSHOT.jar in target folder

Run command line program - 
					Use the command "java -jar FoodTrucks-0.0.1-SNAPSHOT.jar 1" to run the program
					java -jar FoodTrucks-0.0.1-SNAPSHOT.jar - is the run command to execute the jar file and the argument "1" is the page number you want to view the scheduled trucks
					The scheduled trucks displays in size of 10 for each page number input from the run command
					
Run as a web Application - 
					Import the project into any of Java IDE
					Comment the code in FoodTrucksApplication.java as per comments to run as a web application
					Run the project as Spring Boot app or you can use command "mvn spring-boot:run" from command line
					Application starts running on port 8080 by default
					Open browser and add this in address bar - "http://localhost:8080/sfgovFoodTrucks/getFoodTrucks?limit=10&offset=1" and hit enter
					You should be seeing results in JSON based on offset and page size

Application logs - 
				All application logs are logged in the following directory when running from local - C:\opt\app\sfgov\applogs\foodTrucks.log
					

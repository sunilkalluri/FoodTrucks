package com.sfo.gov.foodtrucks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.util.CollectionUtils;

import com.sfo.gov.foodtrucks.config.FoodTrucksServiceAppConfig;
import com.sfo.gov.foodtrucks.response.FoodTrucksFinalResponse;
import com.sfo.gov.foodtrucks.response.FoodTrucksNameAddress;

@SpringBootApplication
@EnableConfigurationProperties( FoodTrucksServiceAppConfig.class)
public class FoodTrucksApplication implements CommandLineRunner{//implemented CommandLineRunner and if need to run as a web application, it can be removed
	
    private static Logger logger = LoggerFactory
    	      .getLogger(FoodTrucksApplication.class);
    
    @Autowired
    com.sfo.gov.foodtrucks.handlers.FoodTrucksServiceHandler FoodTrucksServiceHandler;

	public static void main(String[] args) {
		logger.info("STARTING THE APPLICATION");
		SpringApplication.run(FoodTrucksApplication.class, args);
		logger.info("APPLICATION FINISHED");
	}
	
	//if needed to run from command line, else if need to run as a web application comment this method
	@Override
    public void run(String... args) {
		logger.info("EXECUTING : command line runner args[0] is page number");//please enter page number from command line starts from 0
		FoodTrucksFinalResponse response = FoodTrucksServiceHandler.getFoodTrucks();// This call is just to calculate total size and pages, we can comment if not needed
		int size=0;
		int pages=0;
		if(!CollectionUtils.isEmpty(response.getFoodTrucks())) {
			size = response.getFoodTrucks().size();
			logger.info("Number of food trucks avaiable for the given date time: "+size);
			System.out.println("Number of food trucks avaiable for the given date time: "+size);
			pages = size/10;
			logger.info("Number of food trucks pages avaiable for the given date time (starting from 0): "+(pages+1));
			System.out.println("Number of food trucks pages avaiable for the given date time (starting from 0): "+(pages+1));
		}
		int offset=Integer.valueOf(args[0])*10;
		response = FoodTrucksServiceHandler.getFoodTrucks(10, offset);

		logger.info("*******Display Food Trucks********");
		System.out.println("*******Display Food Trucks********");
		logger.info("Applicant Name\t : Address");
		System.out.println("Applicant Name\t : Address");
		for(FoodTrucksNameAddress foodTrucksNameAddress: response.getFoodTrucks()) {
			logger.info(foodTrucksNameAddress.getApplicant()+"\t: "+foodTrucksNameAddress.getLocation());
			System.out.println(foodTrucksNameAddress.getApplicant()+"\t: "+foodTrucksNameAddress.getLocation());
			
		}
    }

}

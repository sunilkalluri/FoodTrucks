package com.sfo.gov.foodtrucks.assembler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.sfo.gov.foodtrucks.response.FoodTrucksNameAddress;
import com.sfo.gov.foodtrucks.response.FoodTrucksResponse;

/*
 * Assembler to map the applicant name and address to response DTO
 */

@Component
public class FoodTrucksResponseAssembler {

	public List<FoodTrucksNameAddress> mapTrucksNameAndAddressFromResponse(
			final List<FoodTrucksResponse> foodTrucksResponseList) {

		List<FoodTrucksNameAddress> FoodTrucksNameAddressList = new ArrayList<FoodTrucksNameAddress>();
		for (FoodTrucksResponse foodTrucksResponse : foodTrucksResponseList) {
			FoodTrucksNameAddress FoodTrucksNameAddress = new FoodTrucksNameAddress();
			BeanUtils.copyProperties(foodTrucksResponse, FoodTrucksNameAddress);
			FoodTrucksNameAddressList.add(FoodTrucksNameAddress);
		}
		// sort by applicant name ascending
		Comparator<FoodTrucksNameAddress> compareByApplicant = (FoodTrucksNameAddress o1,
				FoodTrucksNameAddress o2) -> o1.getApplicant().compareTo(o2.getApplicant());
		Collections.sort(FoodTrucksNameAddressList, compareByApplicant);
		return FoodTrucksNameAddressList;
	}
}

package com.sfo.gov.foodtrucks.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/*
 * Configuarion class for providing RestTemplate at runtime
 */

@Configuration
public class BeanConfig {
	
	@Autowired
	FoodTrucksServiceAppConfig foodTrucksServiceAppConfig;
    
	@Bean(name = "FoodTruckRestTemplate")
	public RestTemplate getRestTemplate( RestTemplateBuilder restTemplateBuilder) {
		return restTemplateBuilder
	            .build();	
	}

}

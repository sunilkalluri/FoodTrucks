package com.sfo.gov.foodtrucks.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;

/*
 *Configuration class the feed the Rest API params from application yml file at runtime, this can be profiled based on environment 
 */

@PropertySource("classpath:application.yml")
@ConfigurationProperties(prefix = "foodtruckservice")
public class FoodTrucksServiceAppConfig {

	private String endPoint;
	private String apiKey;
	private String apiSecret;

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getApiSecret() {
		return apiSecret;
	}

	public void setApiSecret(String apiSecret) {
		this.apiSecret = apiSecret;
	}

}

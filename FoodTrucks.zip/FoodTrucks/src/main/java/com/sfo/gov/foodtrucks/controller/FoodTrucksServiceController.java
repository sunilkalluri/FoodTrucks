package com.sfo.gov.foodtrucks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sfo.gov.foodtrucks.handlers.FoodTrucksServiceHandler;
import com.sfo.gov.foodtrucks.response.FoodTrucksFinalResponse;

/*
 * Controller to dispatch the API requests
 */

@RestController
@RequestMapping(value = "/sfgovFoodTrucks")
public class FoodTrucksServiceController {

    private final FoodTrucksServiceHandler foodTrucksServiceHandler;
    
    @Autowired
    public FoodTrucksServiceController(final FoodTrucksServiceHandler foodTrucksServiceHandler) {
        this.foodTrucksServiceHandler = foodTrucksServiceHandler;
    }

    @RequestMapping(value = "/getFoodTrucks", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public FoodTrucksFinalResponse getFoodTrucks(@RequestParam("limit") int limit, @RequestParam("offset") int offset) {
        return foodTrucksServiceHandler.getFoodTrucks(limit, offset);
    }
}
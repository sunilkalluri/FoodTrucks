package com.sfo.gov.foodtrucks.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

/*
 * Generalized exception class for the application
 */

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class FoodTrucksServicesException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public FoodTrucksServicesException(String message) {
		super(message);
	}
	
	public FoodTrucksServicesException(String message, Throwable cause) {
		super(message);
		super.initCause(cause);
	}

}

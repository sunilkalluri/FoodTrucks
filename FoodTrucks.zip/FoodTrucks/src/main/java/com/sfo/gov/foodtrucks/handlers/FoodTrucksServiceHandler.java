package com.sfo.gov.foodtrucks.handlers;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.sfo.gov.foodtrucks.FoodTrucksApplication;
import com.sfo.gov.foodtrucks.assembler.FoodTrucksResponseAssembler;
import com.sfo.gov.foodtrucks.exception.FoodTrucksServicesException;
import com.sfo.gov.foodtrucks.helpers.FoodTrucksServiceHelper;
import com.sfo.gov.foodtrucks.response.FoodTrucksFinalResponse;
import com.sfo.gov.foodtrucks.response.FoodTrucksNameAddress;
import com.sfo.gov.foodtrucks.response.FoodTrucksResponse;

/*
 * Handler class dispatched from controller that process the request/responses to/from Rest API call
 */

@Component
public class FoodTrucksServiceHandler {

	@Autowired
	FoodTrucksServiceHelper foodTrucksServiceHelper;

	@Autowired
	FoodTrucksResponseAssembler foodTrucksResponseAssembler;

	//Get total food trucks
	public FoodTrucksFinalResponse getFoodTrucks() {

		Logger logger = LoggerFactory.getLogger(FoodTrucksApplication.class);

		FoodTrucksFinalResponse foodTrucksFinalResponse = new FoodTrucksFinalResponse();
		try {
			LocalDate date = LocalDate.now();
			LocalDateTime datetime = LocalDateTime.now();
			DayOfWeek day = date.getDayOfWeek();
			String dayOfWeek = String.valueOf(day.getValue()).equals("7") ? "0" : String.valueOf(day.getValue());// Sunday
																													// value
																													// is
																													// 7
																													// but
																													// API
																													// has
																													// value
																													// 0
			String hour = datetime.getHour() < 10 ? ("0" + String.valueOf(datetime.getHour()) + ":00")
					: (String.valueOf(datetime.getHour()) + ":00");// prepend with 0 as API start24 is string
			List<FoodTrucksResponse> foodTrucksResponseList = foodTrucksServiceHelper.getFoodTrucks(dayOfWeek, hour);
			if (CollectionUtils.isEmpty(foodTrucksResponseList)) {
				foodTrucksFinalResponse.setErrorMessage("There are no trucks avaiable for the current datetime");
			} else {
				List<FoodTrucksNameAddress> foodTrucksNameAddressList = foodTrucksResponseAssembler
						.mapTrucksNameAndAddressFromResponse(foodTrucksResponseList);
				foodTrucksFinalResponse.setFoodTrucks(foodTrucksNameAddressList);
				foodTrucksFinalResponse.setMessage("Food Trucks retrieved from sf gov successfully");
			}
			foodTrucksFinalResponse.setSuccess(true);
		} catch (FoodTrucksServicesException fte) {
			logger.error(
					"FoodTrucksServiceHandler - getFoodTrucks -  There was an exception in calling food truck service "
							+ fte.getMessage());
			foodTrucksFinalResponse.setSuccess(false);
			foodTrucksFinalResponse.setErrorMessage(
					"Food Trucks failed to retrieve with excption: " + fte.getMessage() + " cause: " + fte.getCause());
		}

		return foodTrucksFinalResponse;

	}
	
	//Get food trucks with pagination
	public FoodTrucksFinalResponse getFoodTrucks(int limit, int offset) {

		Logger logger = LoggerFactory.getLogger(FoodTrucksApplication.class);

		FoodTrucksFinalResponse foodTrucksFinalResponse = new FoodTrucksFinalResponse();
		try {
			LocalDate date = LocalDate.now();
			LocalDateTime datetime = LocalDateTime.now();
			DayOfWeek day = date.getDayOfWeek();
			String dayOfWeek = String.valueOf(day.getValue()).equals("7") ? "0" : String.valueOf(day.getValue());// Sunday
																													// value
																													// is
																													// 7
																													// but
																													// API
																													// has
																													// value
																													// 0
			String hour = datetime.getHour() < 10 ? ("0" + String.valueOf(datetime.getHour()) + ":00")
					: (String.valueOf(datetime.getHour()) + ":00");// prepend with 0 as API start24 is string
			List<FoodTrucksResponse> foodTrucksResponseList = foodTrucksServiceHelper.getFoodTrucks(dayOfWeek, hour, limit, offset);
			if (CollectionUtils.isEmpty(foodTrucksResponseList)) {
				foodTrucksFinalResponse.setErrorMessage("There are no trucks avaiable for the current datetime");
			} else {
				List<FoodTrucksNameAddress> foodTrucksNameAddressList = foodTrucksResponseAssembler
						.mapTrucksNameAndAddressFromResponse(foodTrucksResponseList);
				foodTrucksFinalResponse.setFoodTrucks(foodTrucksNameAddressList);
				foodTrucksFinalResponse.setMessage("Food Trucks retrieved from sf gov successfully");
			}
			foodTrucksFinalResponse.setSuccess(true);
		} catch (FoodTrucksServicesException fte) {
			logger.error(
					"FoodTrucksServiceHandler - getFoodTrucks -  There was an exception in calling food truck service "
							+ fte.getMessage());
			foodTrucksFinalResponse.setSuccess(false);
			foodTrucksFinalResponse.setErrorMessage(
					"Food Trucks failed to retrieve with excption: " + fte.getMessage() + " cause: " + fte.getCause());
		}

		return foodTrucksFinalResponse;

	}

}

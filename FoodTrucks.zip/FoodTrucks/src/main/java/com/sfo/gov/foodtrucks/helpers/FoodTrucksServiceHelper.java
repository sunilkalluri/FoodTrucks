package com.sfo.gov.foodtrucks.helpers;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.RestTemplate;

import com.sfo.gov.foodtrucks.config.FoodTrucksServiceAppConfig;
import com.sfo.gov.foodtrucks.exception.FoodTrucksServicesException;
import com.sfo.gov.foodtrucks.response.FoodTrucksResponse;

/*
 * Helper class used to make REST API call using X-API key fed from application config file
 */

@Component
public class FoodTrucksServiceHelper {
	
	private final Logger logger = LoggerFactory.getLogger(FoodTrucksServiceHelper.class);

	@Autowired
	FoodTrucksServiceAppConfig foodTrucksServiceAppConfig;

	@Autowired
	@Qualifier("FoodTruckRestTemplate")
	RestTemplate restTemplate;

	//Get total food trucks
	public List<FoodTrucksResponse> getFoodTrucks(String dayOfWeek, String hour) throws FoodTrucksServicesException{

		try {
			String foodTrucksServiceEndpoint = foodTrucksServiceAppConfig.getEndPoint()+"?dayorder="+dayOfWeek+"&start24="+hour;
			ResponseEntity<FoodTrucksResponse[]> foodTrucksServiceResponse = restTemplate.getForEntity(foodTrucksServiceEndpoint,
					FoodTrucksResponse[].class);

			/*
			 * Food trucks service returns response code 204 if it does not find food trucks for requested time
			 * 
			 */
			if (foodTrucksServiceResponse.getStatusCode() == HttpStatus.NO_CONTENT) {
				return null;
			}

			return Arrays.asList(foodTrucksServiceResponse.getBody());
		} catch (Exception e) {
			logger.error("FoodTrucksServiceHelper - getFoodTrucks - There was an exception in calling food truck service "
					+ e.getMessage());
			throw new FoodTrucksServicesException(e.getMessage(),e.getCause());
		}
	}
	
	//Get food trucks with pagination
	public List<FoodTrucksResponse> getFoodTrucks(String dayOfWeek, String hour, int limit, int offset) throws FoodTrucksServicesException{

		try {
			String foodTrucksServiceEndpoint = foodTrucksServiceAppConfig.getEndPoint()+"?$limit="+ limit+"&$offset="+offset+"&dayorder="+dayOfWeek+"&start24="+hour;
			ResponseEntity<FoodTrucksResponse[]> foodTrucksServiceResponse = restTemplate.getForEntity(foodTrucksServiceEndpoint,
					FoodTrucksResponse[].class);

			/*
			 * Food trucks service returns response code 204 if it does not find food trucks for requested time
			 * 
			 */
			if (foodTrucksServiceResponse.getStatusCode() == HttpStatus.NO_CONTENT) {
				return null;
			}

			return Arrays.asList(foodTrucksServiceResponse.getBody());
		} catch (Exception e) {
			logger.error("FoodTrucksServiceHelper - getFoodTrucks - There was an exception in calling food truck service "
					+ e.getMessage());
			throw new FoodTrucksServicesException(e.getMessage(),e.getCause());
		}
	}

	/*
	 * Headers to access SFO Gov food trucks API.
	 */
	public HttpHeaders buildHeaders() {

		HttpHeaders requestHeaders = new HttpHeaders();

		requestHeaders.add("Authorization", "Basic " + Base64Utils.encodeToString(
				(foodTrucksServiceAppConfig.getApiKey() + ":" + foodTrucksServiceAppConfig.getApiSecret()).getBytes()));
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		return requestHeaders;
	}

}

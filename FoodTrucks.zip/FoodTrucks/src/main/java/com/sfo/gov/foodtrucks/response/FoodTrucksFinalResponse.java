package com.sfo.gov.foodtrucks.response;

import java.util.List;

/*
 * Hold the final response after assembling the response with required params
 */

public class FoodTrucksFinalResponse {
	
	private String message;
	private String errorMessage;
	private Boolean success;
	private List<FoodTrucksNameAddress> foodTrucks;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public Boolean getSuccess() {
		return success;
	}
	public void setSuccess(Boolean success) {
		this.success = success;
	}
	public List<FoodTrucksNameAddress> getFoodTrucks() {
		return foodTrucks;
	}
	public void setFoodTrucks(List<FoodTrucksNameAddress> foodTrucks) {
		this.foodTrucks = foodTrucks;
	}
}

package com.sfo.gov.foodtrucks.response;

/*
 * Used to map applicant name and location of food truck
 */

public class FoodTrucksNameAddress {
	
	private String applicant;
	private String location;
	
	public String getApplicant() {
		return applicant;
	}
	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}	

}
